import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, CartesianGrid, Legend, PieChart, Pie, Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from "recharts";

// ═══════════════════════════════════════════════════════════════════════
// ENRON TEST — Claude Sonnet 4.6
// Built by Glass Stone | CEO Gabriel B. Rodriguez | 2026
// ═══════════════════════════════════════════════════════════════════════

// ─── REAL HISTORICAL ENRON DATA ──────────────────────────────────────

const STOCK_DATA = [
  { year: "1990", price: 7.13, high: 8.25, low: 5.75 },
  { year: "1991", price: 10.25, high: 11.50, low: 6.88 },
  { year: "1992", price: 12.00, high: 13.13, low: 9.50 },
  { year: "1993", price: 15.88, high: 16.75, low: 11.00 },
  { year: "1994", price: 15.50, high: 17.25, low: 13.25 },
  { year: "1995", price: 19.13, high: 20.00, low: 14.50 },
  { year: "1996", price: 21.56, high: 23.50, low: 18.00 },
  { year: "1997", price: 20.78, high: 22.69, low: 18.44 },
  { year: "1998", price: 28.69, high: 29.44, low: 18.94 },
  { year: "1999", price: 40.25, high: 44.94, low: 28.00 },
  { year: "2000", price: 82.00, high: 90.75, low: 41.00 },
  { year: "Q1 01", price: 72.63, high: 82.00, low: 62.00 },
  { year: "Q2 01", price: 49.40, high: 60.00, low: 42.00 },
  { year: "Q3 01", price: 25.09, high: 42.00, low: 20.00 },
  { year: "Oct 01", price: 13.90, high: 20.00, low: 10.00 },
  { year: "Nov 01", price: 0.61, high: 10.00, low: 0.36 },
  { year: "Dec 01", price: 0.26, high: 0.40, low: 0.12 },
];

const REVENUE_DATA = [
  { year: "1996", revenue: 13.3, reported: 13.3 },
  { year: "1997", revenue: 20.3, reported: 20.3 },
  { year: "1998", revenue: 31.3, reported: 31.3 },
  { year: "1999", revenue: 40.1, reported: 40.1 },
  { year: "2000", revenue: 100.8, reported: 100.8 },
  { year: "2001", revenue: 138.7, reported: 138.7 },
];

const DEBT_HIDDEN = [
  { year: "1999", disclosed: 8.6, hidden: 4.8 },
  { year: "2000", disclosed: 10.2, hidden: 7.2 },
  { year: "2001", disclosed: 13.1, hidden: 12.8 },
];

const SPE_DATA = [
  { name: "LJM1", losses: 1200, created: "1999" },
  { name: "LJM2", losses: 2500, created: "1999" },
  { name: "Raptor I-IV", losses: 1500, created: "2000" },
  { name: "Chewco", losses: 600, created: "1997" },
  { name: "JEDI", losses: 900, created: "1993" },
  { name: "Whitewing", losses: 2400, created: "1999" },
];

const EXECUTIVE_COMPENSATION = [
  { name: "Ken Lay", salary: 6.7, stockSales: 184, total: 217.8 },
  { name: "Jeff Skilling", salary: 5.6, stockSales: 70.7, total: 112.0 },
  { name: "Andy Fastow", salary: 2.4, stockSales: 34.0, total: 60.6 },
  { name: "Lou Pai", salary: 3.1, stockSales: 270.3, total: 280.1 },
  { name: "Ken Rice", salary: 1.8, stockSales: 76.8, total: 82.5 },
];

const TIMELINE_EVENTS = [
  { year: 1985, event: "Enron formed from merger of Houston Natural Gas & InterNorth", category: "corporate" },
  { year: 1989, event: "Begins trading natural gas commodities", category: "corporate" },
  { year: 1990, event: "Jeff Skilling joins as CEO of Enron Finance Corp", category: "corporate" },
  { year: 1991, event: "Adopts mark-to-market accounting for trading operations", category: "accounting" },
  { year: 1993, event: "JEDI partnership created with CalPERS", category: "fraud" },
  { year: 1996, event: "Named 'Most Innovative Company' by Fortune (1st of 6 consecutive)", category: "media" },
  { year: 1997, event: "Chewco SPE created by Andy Fastow to buy out CalPERS stake in JEDI", category: "fraud" },
  { year: 1998, event: "Enron enters water utility business (Azurix); Deregulation accelerates under Phil Gramm", category: "political" },
  { year: 1999, event: "EnronOnline launched—becomes largest e-commerce site; LJM1 & LJM2 partnerships created by Fastow", category: "fraud" },
  { year: 2000, event: "Revenue hits $101B—7th largest US company; Stock peaks at $90.75; California energy crisis begins", category: "peak" },
  { year: 2001, event: "Jan: George W. Bush inaugurated (Lay major donor); Cheney energy task force meets with Enron execs", category: "political" },
  { year: 2001.2, event: "Feb: Jeff Skilling becomes CEO; Lay remains chairman", category: "corporate" },
  { year: 2001.4, event: "Aug 14: Skilling resigns after 6 months as CEO, cites 'personal reasons'", category: "collapse" },
  { year: 2001.5, event: "Aug 15: Sherron Watkins sends anonymous memo to Ken Lay warning of accounting irregularities", category: "whistleblower" },
  { year: 2001.6, event: "Oct 16: Enron reports $618M Q3 loss and $1.2B equity reduction", category: "collapse" },
  { year: 2001.65, event: "Oct 22: SEC opens formal investigation into Enron", category: "collapse" },
  { year: 2001.7, event: "Oct 24: Andy Fastow removed as CFO", category: "collapse" },
  { year: 2001.75, event: "Nov 8: Enron restates 4+ years of financials—$586M in earnings vanish", category: "collapse" },
  { year: 2001.8, event: "Nov 28: Dynegy merger collapses; stock drops to $0.61", category: "collapse" },
  { year: 2001.9, event: "Dec 2: Enron files Chapter 11—largest bankruptcy in US history at the time", category: "collapse" },
  { year: 2002, event: "Jan: Arthur Andersen admits shredding Enron documents; DOJ launches criminal investigation", category: "aftermath" },
  { year: 2002.5, event: "Jun: Arthur Andersen convicted of obstruction—effectively destroyed (85,000 jobs lost)", category: "aftermath" },
  { year: 2002.7, event: "Jul: Sarbanes-Oxley Act signed into law in direct response to Enron/WorldCom", category: "political" },
  { year: 2004, event: "Andy Fastow pleads guilty to 2 counts of conspiracy, sentenced to 6 years", category: "legal" },
  { year: 2006, event: "May: Lay and Skilling found guilty on multiple counts of fraud and conspiracy", category: "legal" },
  { year: 2006.5, event: "Jul 5: Ken Lay dies of heart attack before sentencing", category: "legal" },
  { year: 2006.8, event: "Oct: Jeff Skilling sentenced to 24 years, 4 months in prison", category: "legal" },
];

// ─── DIFFICULTY TIERS ────────────────────────────────────────────────

const DIFFICULTY_TIERS = {
  kenlay: {
    name: "Ken Lay",
    title: "Chairman & CEO",
    subtitle: "\"I had no idea\"",
    level: "EASY",
    color: "#4CAF50",
    bg: "rgba(76,175,80,0.12)",
    border: "rgba(76,175,80,0.4)",
    description: "The friendly face of fraud. Basic questions about Enron's history, key people, and major events. Perfect for those just learning the story.",
    timePerQuestion: 45,
    hintAllowed: 3,
    questionCount: 12,
    icon: "🎩",
    fate: "Found guilty on 10 counts. Died July 5, 2006 before sentencing. Convictions vacated."
  },
  fastow: {
    name: "Andy Fastow",
    title: "Chief Financial Officer",
    subtitle: "\"The SPE Architect\"",
    level: "MEDIUM",
    color: "#FF9800",
    bg: "rgba(255,152,0,0.12)",
    border: "rgba(255,152,0,0.4)",
    description: "The man behind the partnerships. Questions on financial structures, SPEs, and the mechanics of the fraud. Requires understanding of corporate finance.",
    timePerQuestion: 35,
    hintAllowed: 2,
    questionCount: 15,
    icon: "📊",
    fate: "Pleaded guilty. Cooperated with prosecutors. Sentenced to 6 years, served 5. Released 2011."
  },
  skilling: {
    name: "Jeff Skilling",
    title: "President & CEO",
    subtitle: "\"The Smartest Guy in the Room\"",
    level: "HARD",
    color: "#f44336",
    bg: "rgba(244,67,54,0.12)",
    border: "rgba(244,67,54,0.4)",
    description: "Mark-to-market everything. Deep questions on accounting practices, regulatory failures, market manipulation, and the California energy crisis.",
    timePerQuestion: 25,
    hintAllowed: 1,
    questionCount: 18,
    icon: "🧠",
    fate: "Found guilty on 19 counts. Sentenced to 24 years. Reduced to 14 years. Released Feb 2019."
  },
  watkins: {
    name: "Sherron Watkins",
    title: "VP Corporate Development",
    subtitle: "\"The Whistleblower\"",
    level: "EXPERT",
    color: "#9C27B0",
    bg: "rgba(156,39,176,0.12)",
    border: "rgba(156,39,176,0.4)",
    description: "See through the lies. Expert-level questions requiring deep knowledge of accounting fraud mechanics, regulatory gaps, political entanglements, and systemic failures.",
    timePerQuestion: 20,
    hintAllowed: 0,
    questionCount: 20,
    icon: "🔍",
    fate: "Named TIME Person of the Year 2002 (with 2 other whistleblowers). Career in corporate governance advocacy."
  },
};

// ─── QUESTION BANK ───────────────────────────────────────────────────

const QUESTIONS = {
  kenlay: [
    { q: "Enron was formed in 1985 from the merger of which two companies?", options: ["Houston Natural Gas & InterNorth", "Texaco & Gulf Oil", "Williams Companies & El Paso Energy", "Pacific Gas & Dynegy"], answer: 0, category: "History", explanation: "Kenneth Lay orchestrated the 1985 merger of Houston Natural Gas (where he was CEO) and InterNorth, an Omaha-based pipeline company, creating Enron Corp." },
    { q: "What was Enron's peak stock price?", options: ["$45.25", "$90.75", "$120.00", "$67.50"], answer: 1, category: "Finance", explanation: "Enron stock reached an all-time high of $90.75 per share in August 2000, giving the company a market capitalization of approximately $70 billion." },
    { q: "In what year did Enron file for bankruptcy?", options: ["2000", "2001", "2002", "2003"], answer: 1, category: "History", explanation: "Enron filed for Chapter 11 bankruptcy on December 2, 2001. At the time, it was the largest corporate bankruptcy in American history." },
    { q: "How many consecutive years was Enron named 'Most Innovative Company' by Fortune magazine?", options: ["3", "4", "6", "8"], answer: 2, category: "Media", explanation: "Fortune named Enron 'America's Most Innovative Company' for six consecutive years from 1996 to 2001 — right up until the scandal broke." },
    { q: "Approximately how many employees lost their jobs when Enron collapsed?", options: ["5,000", "12,000", "20,000", "35,000"], answer: 2, category: "Impact", explanation: "About 20,000 Enron employees lost their jobs. Many also lost their life savings, as retirement accounts were heavily invested in Enron stock." },
    { q: "What was Enron's reported revenue in 2000?", options: ["$40.1 billion", "$67.3 billion", "$100.8 billion", "$138.7 billion"], answer: 2, category: "Finance", explanation: "Enron reported $100.8 billion in revenue for fiscal year 2000, making it the 7th largest company in the United States by revenue." },
    { q: "Which accounting firm was Enron's auditor?", options: ["PricewaterhouseCoopers", "Deloitte & Touche", "Arthur Andersen", "Ernst & Young"], answer: 2, category: "Governance", explanation: "Arthur Andersen served as Enron's outside auditor. The firm was convicted of obstruction of justice for shredding Enron-related documents and effectively ceased to exist." },
    { q: "Who was Enron's CEO who resigned in August 2001 after just 6 months?", options: ["Ken Lay", "Jeff Skilling", "Andy Fastow", "Richard Causey"], answer: 1, category: "People", explanation: "Jeff Skilling became CEO in February 2001 and abruptly resigned on August 14, 2001, citing 'personal reasons.' He sold $60+ million in stock around this period." },
    { q: "What was the stock price when Enron filed for bankruptcy?", options: ["$4.01", "$1.00", "$0.26", "$0.61"], answer: 2, category: "Finance", explanation: "By December 2, 2001, Enron's stock had fallen to $0.26 per share — down from its peak of $90.75 just 16 months earlier, a 99.7% loss." },
    { q: "What major U.S. legislation was passed as a direct result of the Enron scandal?", options: ["Dodd-Frank Act", "Glass-Steagall Act", "Sarbanes-Oxley Act", "Securities Exchange Act"], answer: 2, category: "Political", explanation: "The Sarbanes-Oxley Act of 2002 was signed into law on July 30, 2002, establishing new standards for corporate accountability and financial disclosures." },
    { q: "Which Enron executive was known as 'The Whistleblower'?", options: ["Rebecca Mark", "Sherron Watkins", "Cindy Olson", "Margaret Ceconi"], answer: 1, category: "People", explanation: "VP Sherron Watkins sent a 7-page anonymous memo to Ken Lay on August 15, 2001, warning that the company could 'implode in a wave of accounting scandals.'" },
    { q: "What state was Enron headquartered in?", options: ["New York", "California", "Texas", "Delaware"], answer: 2, category: "History", explanation: "Enron was headquartered in Houston, Texas. Its 50-story downtown headquarters became an iconic symbol of the scandal." },
  ],
  fastow: [
    { q: "What does 'SPE' stand for in the context of Enron's fraud?", options: ["Standard Portfolio Equity", "Special Purpose Entity", "Structured Partnership Exchange", "Securities & Private Equity"], answer: 1, category: "Accounting", explanation: "Special Purpose Entities are legal entities created for a specific, limited purpose. Fastow created dozens of SPEs to hide Enron's debt and inflate its earnings." },
    { q: "Which SPE was created by Fastow specifically to buy CalPERS' stake in the JEDI partnership?", options: ["LJM1", "Raptor", "Chewco", "Whitewing"], answer: 2, category: "SPEs", explanation: "Chewco (named after Chewbacca from Star Wars) was created in 1997 to buy CalPERS' stake in JEDI so Enron wouldn't have to consolidate JEDI's debt on its balance sheet." },
    { q: "Under GAAP rules at the time, what minimum percentage of outside equity was required for SPE non-consolidation?", options: ["1%", "3%", "5%", "10%"], answer: 1, category: "Accounting", explanation: "GAAP required only 3% independent outside equity for an SPE to remain off the parent's balance sheet — an extremely thin requirement that Enron exploited aggressively." },
    { q: "What accounting method did Enron adopt in 1991 that allowed it to book projected future profits immediately?", options: ["Cash-basis accounting", "Mark-to-market accounting", "Accrual smoothing", "Revenue matching"], answer: 1, category: "Accounting", explanation: "Mark-to-market accounting allowed Enron to record estimated future profits from long-term contracts as current revenue — even if no cash had been received." },
    { q: "Approximately how much did Andy Fastow personally earn from the LJM partnerships?", options: ["$2 million", "$12 million", "$30 million", "$60 million"], answer: 3, category: "Fraud", explanation: "Fastow earned at least $60 million from the LJM partnerships he managed — a clear conflict of interest as Enron's CFO negotiating deals with entities he controlled." },
    { q: "The Raptor SPEs were used primarily to:", options: ["Generate trading revenue", "Hedge Enron's merchant investments", "Pay executive bonuses", "Finance pipeline construction"], answer: 1, category: "SPEs", explanation: "The four Raptor vehicles (I through IV) were used to hedge the declining value of Enron's merchant investments, masking over $1 billion in losses." },
    { q: "What secured the Raptor SPEs' ability to appear solvent?", options: ["Cash reserves from JP Morgan", "Enron's own stock", "U.S. Treasury bonds", "Insurance from AIG"], answer: 1, category: "SPEs", explanation: "The Raptors were capitalized primarily with Enron's own stock — creating a fatal circular dependency. When Enron's stock fell, the hedges collapsed simultaneously." },
    { q: "How much in hidden debt was Enron keeping off its balance sheet through SPEs by 2001?", options: ["$3 billion", "$8 billion", "$13 billion", "$20 billion"], answer: 2, category: "Finance", explanation: "By 2001, Enron had approximately $13 billion in obligations hidden off its balance sheet through hundreds of SPEs — nearly equal to its disclosed debt." },
    { q: "What was the 'LJM' in LJM Capital Management named after?", options: ["Latin financial terms", "Fastow's wife and children's initials", "A Star Wars reference", "Lay, Jeff, and Michael (Kopper)"], answer: 1, category: "SPEs", explanation: "LJM stands for Lea, Jeffrey, Matthew — the first names of Andy Fastow's wife and two sons. He named his fraud vehicle after his family." },
    { q: "What role did banks like JP Morgan and Citigroup play in Enron's scheme?", options: ["They were uninvolved passive lenders", "They helped structure prepay transactions disguised as trades to hide loans", "They only provided standard corporate credit lines", "They served exclusively as Enron's investment banking advisors"], answer: 1, category: "Finance", explanation: "JP Morgan and Citigroup helped Enron structure 'prepay' transactions that were essentially disguised loans, allowing Enron to book debt as trading revenue." },
    { q: "When Enron restated its financials in November 2001, how much in earnings was erased?", options: ["$186 million", "$386 million", "$586 million", "$1.2 billion"], answer: 2, category: "Accounting", explanation: "On November 8, 2001, Enron restated four years of financial results, eliminating $586 million in reported earnings and adding $2.6 billion in debt." },
    { q: "The Enron board waived its conflict-of-interest code of ethics specifically to allow:", options: ["Ken Lay to serve as both chairman and CEO", "Fastow to manage the LJM partnerships while serving as CFO", "Skilling to trade company stock freely", "Arthur Andersen to provide both auditing and consulting"], answer: 1, category: "Governance", explanation: "Enron's board voted twice to waive its code of conduct to allow Fastow to run LJM while serving as CFO — one of the most egregious governance failures in the scandal." },
    { q: "What credit rating triggered Enron's final liquidity crisis?", options: ["Downgrade from AAA to AA", "Downgrade from A to BBB", "Downgrade to below investment grade (junk)", "Removal from S&P 500"], answer: 2, category: "Finance", explanation: "When Moody's and S&P downgraded Enron to below investment grade on November 28, 2001, it triggered $3.9 billion in debt obligations, making bankruptcy inevitable." },
    { q: "What was Michael Kopper's role in Enron's fraud?", options: ["Chief Accounting Officer", "Fastow's managing director who ran Chewco", "Enron's general counsel", "Head of Enron Broadband"], answer: 1, category: "People", explanation: "Michael Kopper was Fastow's deputy who managed Chewco and other SPEs. He was the first Enron executive to plead guilty, cooperating extensively with prosecutors." },
    { q: "How much of the average Enron employee's 401(k) was invested in Enron stock?", options: ["About 20%", "About 40%", "About 62%", "About 85%"], answer: 2, category: "Impact", explanation: "The average Enron employee had approximately 62% of their 401(k) invested in Enron stock. Many lost their entire retirement savings in the collapse." },
  ],
  skilling: [
    { q: "In mark-to-market accounting as applied by Enron, how was the value of a 20-year energy contract typically determined?", options: ["By the actual cash flows received to date", "By internal models using assumptions about future prices", "By independent third-party appraisal only", "By the contract's face value minus operating costs"], answer: 1, category: "Accounting", explanation: "Enron's mark-to-market approach used internal models with management assumptions about future commodity prices, discount rates, and volumes — easily manipulated." },
    { q: "What was Enron's role in the California energy crisis of 2000-2001?", options: ["They were uninvolved — it was purely a supply shortage", "Enron traders manipulated wholesale electricity markets using strategies like 'Death Star' and 'Fat Boy'", "They only sold retail electricity at fair market prices", "They exclusively traded natural gas, not electricity"], answer: 1, category: "Market Manipulation", explanation: "Enron traders used strategies with code names like 'Death Star,' 'Fat Boy,' and 'Get Shorty' to manipulate California's newly deregulated electricity market." },
    { q: "Senator Phil Gramm's connection to Enron included:", options: ["He was Enron's general counsel before entering politics", "His wife Wendy served on Enron's board; he championed the Commodity Futures Modernization Act exempting energy trading from regulation", "He personally invested $50M in LJM partnerships", "He served as Enron's registered lobbyist"], answer: 1, category: "Political", explanation: "Wendy Gramm chaired the CFTC before joining Enron's board. Phil Gramm pushed the Commodity Futures Modernization Act of 2000, which exempted energy trading from oversight." },
    { q: "What was the 'Enron Death Star' trading strategy?", options: ["A plan to bankrupt competing utilities", "Booking fictional electricity transmission to collect congestion payments from California's grid operator", "A hostile takeover strategy for acquiring pipeline companies", "A short-selling strategy against Enron's own stock"], answer: 1, category: "Market Manipulation", explanation: "Death Star involved scheduling fake power transmissions on California's grid, then collecting congestion relief payments for 'not transmitting' — pure phantom transactions." },
    { q: "How much did Enron spend on political contributions and lobbying from 1989 to 2001?", options: ["About $3 million", "About $12 million", "About $25 million", "About $6 million"], answer: 3, category: "Political", explanation: "Enron spent approximately $6 million in political contributions and millions more on lobbying — Ken Lay was George W. Bush's largest career patron (nicknamed 'Kenny Boy')." },
    { q: "Arthur Andersen's Houston office shredded how many boxes of Enron documents?", options: ["A few dozen", "Approximately one ton / thousands of boxes", "About 500 pages", "Records were digitally deleted, not shredded"], answer: 1, category: "Cover-up", explanation: "Beginning October 23, 2001 (the day after SEC inquiry), Andersen's Houston office ran shredders around the clock, destroying approximately one ton of documents." },
    { q: "What was unique about Enron's 'asset-light' business model under Skilling?", options: ["It sold all physical assets to focus on pure financial trading and intermediation", "It outsourced all operations to India", "It only invested in renewable energy", "It operated exclusively as a regulated utility"], answer: 0, category: "Strategy", explanation: "Skilling transformed Enron from an asset-heavy pipeline company into an 'asset-light' trading intermediary — essentially becoming an unregulated financial institution." },
    { q: "The Commodity Futures Modernization Act of 2000 affected Enron by:", options: ["Requiring more transparency in energy trading", "Exempting over-the-counter energy derivatives from CFTC regulation", "Mandating independent audits of trading positions", "Forcing Enron to register as a financial institution"], answer: 1, category: "Regulatory", explanation: "The CFMA created the 'Enron Loophole' — exempting OTC energy derivatives from CFTC oversight, allowing Enron to trade billions in energy contracts with zero regulatory oversight." },
    { q: "What happened to Enron's stock price between August 22 and October 16, 2001?", options: ["It remained stable around $40", "It dropped from ~$36 to ~$33 — a modest decline", "It crashed from ~$36 to ~$25 amid growing suspicion", "It actually increased due to buyback programs"], answer: 2, category: "Collapse", explanation: "Between Skilling's August 14 resignation and the October 16 earnings announcement, the stock eroded as analysts, short-sellers, and journalists probed deeper." },
    { q: "Jim Chanos of Kynikos Associates was significant because:", options: ["He was Enron's largest institutional investor", "He was one of the first prominent short-sellers to publicly question Enron's financials", "He served as Enron's outside financial advisor", "He wrote the Sarbanes-Oxley legislation"], answer: 1, category: "Collapse", explanation: "Short-seller Jim Chanos began shorting Enron in November 2000 after analyzing its 10-K and finding the company's return on invested capital was only ~7% despite claims of high profitability." },
    { q: "Bethany McLean's famous Fortune article that first publicly questioned Enron was titled:", options: ["'The Fall of Enron'", "'Enron: The House of Cards'", "'Is Enron Overpriced?'", "'Cooking the Books at Enron'"], answer: 2, category: "Media", explanation: "Bethany McLean's March 2001 Fortune article 'Is Enron Overpriced?' was the first major media piece to question how Enron actually made its money — a question nobody could answer clearly." },
    { q: "What was 'Enron Broadband Services' and why did it matter?", options: ["Enron's successful internet division that generated real profits", "A division that traded bandwidth as a commodity — Enron booked $110M in profits from a Blockbuster deal that was never viable", "A standard ISP that Enron acquired in 1999", "The technology division that built EnronOnline"], answer: 1, category: "Fraud", explanation: "Enron Broadband used mark-to-market to book $110M from a video-on-demand deal with Blockbuster that was essentially worthless, and traded bandwidth that had no liquid market." },
    { q: "How many total felony counts was Jeff Skilling convicted of?", options: ["6", "12", "19", "24"], answer: 2, category: "Legal", explanation: "Skilling was convicted on 19 of 28 counts including conspiracy, securities fraud, insider trading, and making false statements. He was sentenced to 24 years, later reduced to 14." },
    { q: "What was the total estimated loss to Enron shareholders?", options: ["$11 billion", "$40 billion", "$74 billion", "$100 billion"], answer: 2, category: "Impact", explanation: "Enron shareholders lost approximately $74 billion in market value in the four years before the bankruptcy — including $40 billion in the final year alone." },
    { q: "The Powers Report (2002) was:", options: ["A congressional investigation led by Senator Powers", "An internal investigation by Enron's board, led by William Powers Jr., detailing the extent of financial manipulation", "A report by the SEC on market reform", "A report by Arthur Andersen defending its audit work"], answer: 1, category: "Aftermath", explanation: "The Powers Report, commissioned by Enron's own board and led by UT Austin Dean William Powers Jr., concluded that Enron's failures were 'extensive and devastating.'" },
    { q: "Which Enron executive sold $270 million in stock before the collapse — more than any other?", options: ["Ken Lay", "Jeff Skilling", "Lou Pai", "Andy Fastow"], answer: 2, category: "People", explanation: "Lou Pai, CEO of Enron Energy Services, sold $270M in stock — the most of any executive. He resigned in 2001 and used proceeds to buy a 77,000-acre ranch in Colorado." },
    { q: "What was Enron's actual return on invested capital (ROIC) when Chanos analyzed it?", options: ["About 2%", "About 7%", "About 15%", "About 23%"], answer: 1, category: "Finance", explanation: "Despite claims of extraordinary profitability, Chanos found Enron's ROIC was approximately 7% — below its cost of capital, meaning it was destroying value, not creating it." },
    { q: "Enron's board included all of the following structural governance failures EXCEPT:", options: ["Board members had financial ties to Enron through consulting arrangements", "The audit committee met for an average of just 1 hour per session", "The board had no independent directors whatsoever", "The board waived conflict-of-interest policies for Fastow's partnerships"], answer: 2, category: "Governance", explanation: "Enron technically had independent directors, but many had financial ties to the company. The board's failures were qualitative (rubber-stamping) rather than structural (no independence)." },
  ],
  watkins: [
    { q: "Under FAS 140 (Transfers of Financial Assets), Enron's SPE structures violated the standard because:", options: ["They used related-party capital counted as the 3% outside equity", "They exceeded the maximum number of allowed SPEs per parent company", "They failed to register with the SEC as investment companies", "They used non-U.S. domiciled entities"], answer: 0, category: "Technical Accounting", explanation: "Many of Enron's SPEs used capital from Enron-related parties (like Kopper) as the 'independent' 3% equity — violating the independence requirement even under the permissive FAS 140 rules." },
    { q: "The circular dependency in the Raptor structures meant that:", options: ["Raptor profits and Enron profits moved independently", "As Enron's stock declined, the hedges meant to protect Enron simultaneously lost value — making the protection illusory", "Raptors could only lose money if commodity prices fell", "Enron could unwind Raptor positions without any cash outlay"], answer: 1, category: "SPE Mechanics", explanation: "Because Raptors were capitalized with Enron stock, any decline in Enron's share price reduced the Raptors' ability to pay on the hedges — a self-defeating circular structure." },
    { q: "Sherron Watkins' August 2001 memo specifically warned about which accounting issue?", options: ["Mark-to-market revenue recognition on broadband deals", "The Raptor SPE structures and their reliance on Enron stock", "Insider trading by Ken Lay", "California electricity market manipulation"], answer: 1, category: "Whistleblowing", explanation: "Watkins specifically warned that Enron could 'implode in a wave of accounting scandals' because the Raptor structures would collapse when Enron's stock fell below certain triggers." },
    { q: "What was the 'Enron Loophole' formally known as, and what section of law created it?", options: ["Section 2(h) of the Commodity Exchange Act, as amended by CFMA 2000", "Section 404 of Sarbanes-Oxley", "Rule 10b-5 of the Securities Exchange Act", "Section 20A of the Gramm-Leach-Bliley Act"], answer: 0, category: "Regulatory", explanation: "Section 2(h) of the Commodity Exchange Act, as amended by the CFMA 2000, exempted bilateral OTC energy trading from CFTC oversight — the 'Enron Loophole' closed only in 2008." },
    { q: "The total-return-swap structure used between Enron and the Raptors functioned by:", options: ["Transferring actual ownership of assets to the Raptor", "Allowing Enron to receive payments based on asset value changes while retaining the actual economic risk", "Providing genuine risk transfer to an independent counterparty", "Creating tax benefits through offshore depreciation"], answer: 1, category: "SPE Mechanics", explanation: "The total-return swaps gave the appearance of risk transfer but Enron retained the economic exposure — making the hedges accounting fictions rather than genuine risk mitigation." },
    { q: "What critical assumption made Enron's mark-to-market profits on long-term contracts essentially fictional?", options: ["The assumption that Enron would maintain its credit rating indefinitely", "The use of internal discount rates and price curves with no liquid market to verify fair value", "The assumption that all contracts would be physically delivered", "The use of GAAP rather than IFRS standards"], answer: 1, category: "Accounting", explanation: "For illiquid, long-dated contracts (20+ year deals), there was no observable market price. Enron used internal models with management-chosen assumptions — essentially choosing their own profits." },
    { q: "The Senate Permanent Subcommittee on Investigations found that Enron's board failed in which specific fiduciary duties?", options: ["Only the duty of care", "Only the duty of loyalty", "Both duty of care and duty of loyalty, plus allowing excessive compensation, conflicts of interest, and accounting manipulation", "The board was found to have met all fiduciary duties"], answer: 2, category: "Governance", explanation: "The Senate found the board failed both duties — approving Fastow's conflicts (loyalty), not questioning financials (care), and rubber-stamping excessive compensation structures." },
    { q: "How did Enron's 'prepay' transactions with banks technically differ from standard loans?", options: ["They carried no interest", "They were structured as commodity trades through offshore intermediary entities like Mahonia Ltd, allowing classification as trading activity rather than debt", "They were backed by U.S. government guarantees", "They were denominated in foreign currencies"], answer: 1, category: "Finance", explanation: "Prepays routed through offshore entities like Mahonia (JP Morgan) and Delta/Yosemite (Citigroup) to disguise loans as commodity trades — keeping billions off the balance sheet as 'trading liabilities.'" },
    { q: "The 'Rhythms NetConnections' transaction exposed a fundamental flaw in Enron's hedging because:", options: ["Rhythms stock was illiquid and restricted", "Enron hedged its Rhythms investment using SPE LJM1, capitalized with Enron stock — meaning a decline in tech stocks would impair both the hedged asset and the hedge simultaneously", "The options contracts expired before the hedge period ended", "Rhythms was a subsidiary of Enron"], answer: 1, category: "SPE Mechanics", explanation: "Enron held restricted Rhythms stock and 'hedged' it through LJM1, capitalized with Enron shares. Both were tech-correlated — when tech fell, both the asset and hedge lost value." },
    { q: "What specific change did Sarbanes-Oxley Section 302 require that directly addressed Enron-type fraud?", options: ["Annual auditor rotation", "CEO and CFO personal certification of financial statements' accuracy, with criminal penalties for knowing violations", "Mandatory stock lockup periods for all employees", "Creation of the PCAOB"], answer: 1, category: "Regulatory", explanation: "Section 302 requires CEO/CFO to personally certify the accuracy of financial reports — directly responding to Lay and Skilling's claims that they didn't know about the fraud." },
    { q: "The $1.2 billion equity reduction Enron announced on October 16, 2001 was actually caused by:", options: ["Normal operating losses from Enron's trading division", "Unwinding the Raptor SPE structures, which required Enron to recognize losses it had previously hidden", "A write-down of Azurix water utility assets", "Settlement of California energy crisis lawsuits"], answer: 1, category: "Collapse", explanation: "The equity reduction came from collapsing the Raptor structures — Enron had to recognize $1.2 billion in shareholder equity that had been illusorily propping up the SPEs." },
    { q: "Vinson & Elkins, Enron's outside law firm, was criticized for:", options: ["Failing to file required SEC disclosures on time", "Conducting a review of Watkins' allegations but limiting scope to exclude the core accounting issues and concluding no action was needed", "Representing both Enron and Arthur Andersen simultaneously", "Failing to pay outside consultants"], answer: 1, category: "Governance", explanation: "V&E reviewed Watkins' claims but was told not to examine the actual accounting — then concluded there was no problem. The firm had earned $35M+ from Enron and had clear conflicts." },
    { q: "Under the pre-Enron regulatory framework, what entity had primary responsibility for overseeing Enron's accounting?", options: ["The CFTC", "The SEC, through periodic 10-K/10-Q reviews, but Enron's filings were not substantively reviewed for years", "The FDIC", "The Federal Energy Regulatory Commission"], answer: 1, category: "Regulatory", explanation: "The SEC had oversight but did not substantively review Enron's increasingly complex financial disclosures for years — a systemic failure in the review process that SOX aimed to fix." },
    { q: "What was the maximum sentence Jeff Skilling faced at trial, and why was it later reduced?", options: ["Life imprisonment; reduced on appeal based on sentencing guidelines", "45 years; reduced to 24.3 years at sentencing, then to 14 years after Supreme Court narrowed honest-services fraud statute in Skilling v. United States (2010)", "30 years; reduced due to cooperation with prosecutors", "20 years; reduced for good behavior"], answer: 1, category: "Legal", explanation: "The Supreme Court's 2010 decision in Skilling v. United States narrowed the honest-services fraud statute, leading to resentencing. Skilling agreed to 14 years in a deal that released $40M to victims." },
    { q: "What structural problem with U.S. accounting standards (pre-SOX) did Enron most critically exploit?", options: ["The lack of any requirement for quarterly reporting", "The rules-based nature of GAAP, which allowed technical compliance while violating the economic substance of transactions", "The absence of any auditing requirements for public companies", "The ability to use foreign accounting standards"], answer: 1, category: "Systemic", explanation: "GAAP's rules-based approach allowed Enron to structure transactions that technically met specific rules while completely violating the spirit and economic substance of those rules." },
    { q: "How did the destruction of Arthur Andersen affect the accounting profession systemically?", options: ["It had minimal impact since Andersen was a small firm", "It reduced the Big 5 to the Big 4, creating an oligopoly with less competitive pressure and fewer choices for major audit clients", "It led to the creation of dozens of new accounting firms", "It only affected Andersen's Houston office"], answer: 1, category: "Systemic", explanation: "Andersen's death (85,000 employees, $9.3B revenue) reduced major audit firms from 5 to 4, concentrating market power and reducing competitive alternatives for large public companies." },
    { q: "Richard Causey (Chief Accounting Officer) was significant because:", options: ["He was the first executive arrested", "He was the person responsible for implementing the specific accounting entries that created the fraud — the technical executioner of Fastow and Skilling's designs", "He was Enron's founder", "He ran the California trading desk"], answer: 1, category: "People", explanation: "Causey translated Skilling's strategies and Fastow's structures into actual accounting entries. He initially faced 31 charges, eventually pleading guilty to securities fraud (7 years, served 5.5)." },
    { q: "What was the total estimated economic damage of the Enron scandal including indirect effects?", options: ["$5 billion", "$30 billion", "$74 billion in market cap loss alone, plus $2B+ in pension losses, Arthur Andersen's destruction, and regulatory/compliance costs industry-wide", "Approximately $200 billion"], answer: 2, category: "Impact", explanation: "Beyond the $74B shareholder loss: $2B+ in pension losses, 85,000 Andersen jobs, billions in new compliance costs (SOX), and immeasurable damage to market confidence." },
    { q: "Why did Enron's use of 'gain-on-sale' accounting for its merchant investments compound the mark-to-market problem?", options: ["It allowed Enron to book the entire expected lifetime profit of an investment at the moment of partial or structured 'sale' to a related SPE", "It delayed revenue recognition appropriately", "It only applied to physical asset sales", "It was required by FASB for all energy companies"], answer: 0, category: "Technical Accounting", explanation: "Gain-on-sale allowed Enron to 'sell' investments to its own SPEs, book the full expected lifetime value as immediate profit, while retaining the actual economic risk through total-return swaps." },
    { q: "The Batson Report (Enron's bankruptcy examiner report) concluded that Enron's directors:", options: ["Acted appropriately at all times", "Were victims of deception with no culpability", "Bore significant responsibility because they were presented with clear warning signs and chose not to act, approving every critical transaction that enabled the fraud", "Had no involvement in financial decisions"], answer: 2, category: "Governance", explanation: "The 4,000-page Batson Report detailed how directors approved Fastow's conflicts, rubber-stamped complex SPEs they didn't understand, and ignored multiple warning signs over years." },
  ],
};

// ─── CUSTOM TOOLTIP ──────────────────────────────────────────────────

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: "rgba(10,10,15,0.95)", border: "1px solid rgba(212,175,55,0.4)", borderRadius: 8, padding: "10px 14px", fontFamily: "'DM Mono', monospace", fontSize: 12 }}>
        <p style={{ color: "#D4AF37", margin: 0, fontWeight: 700 }}>{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color || "#fff", margin: "4px 0 0", fontSize: 11 }}>
            {p.name}: {typeof p.value === "number" ? (p.value < 1 ? `$${p.value.toFixed(2)}` : p.name.includes("evenue") || p.name.includes("ebt") ? `$${p.value}B` : `$${p.value.toFixed(2)}`) : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

// ─── ANIMATED BACKGROUND ─────────────────────────────────────────────

const AnimatedBG = () => {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let animId;
    let particles = [];
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    window.addEventListener("resize", resize);
    for (let i = 0; i < 60; i++) {
      particles.push({
        x: Math.random() * canvas.width, y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
        r: Math.random() * 2 + 0.5, opacity: Math.random() * 0.4 + 0.1
      });
    }
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(212,175,55,${p.opacity})`;
        ctx.fill();
      });
      particles.forEach((a, i) => {
        particles.slice(i + 1).forEach(b => {
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `rgba(212,175,55,${0.08 * (1 - dist / 120)})`;
            ctx.stroke();
          }
        });
      });
      animId = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(animId); window.removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={canvasRef} style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 0 }} />;
};

// ─── MAIN APP ────────────────────────────────────────────────────────

const VIEWS = { LANDING: 0, SELECT: 1, DATA: 2, QUIZ: 3, RESULTS: 4, TIMELINE: 5 };

export default function EnronTest() {
  const [view, setView] = useState(VIEWS.LANDING);
  const [difficulty, setDifficulty] = useState(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [timer, setTimer] = useState(0);
  const [hintsLeft, setHintsLeft] = useState(0);
  const [hintUsed, setHintUsed] = useState(false);
  const [eliminatedOptions, setEliminatedOptions] = useState([]);
  const [totalTime, setTotalTime] = useState(0);
  const [fadeIn, setFadeIn] = useState(false);
  const [dataTab, setDataTab] = useState("stock");
  const timerRef = useRef(null);

  useEffect(() => { setFadeIn(true); }, []);

  const tier = difficulty ? DIFFICULTY_TIERS[difficulty] : null;
  const questions = difficulty ? QUESTIONS[difficulty] : [];
  const currentQuestion = questions[currentQ];

  // Timer
  useEffect(() => {
    if (view === VIEWS.QUIZ && !showExplanation && tier) {
      setTimer(tier.timePerQuestion);
      timerRef.current = setInterval(() => {
        setTimer(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            handleAnswer(-1);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timerRef.current);
    }
  }, [currentQ, view, showExplanation]);

  const handleAnswer = useCallback((idx) => {
    if (showExplanation) return;
    clearInterval(timerRef.current);
    setSelected(idx);
    setShowExplanation(true);
    const correct = idx === currentQuestion?.answer;
    if (correct) setScore(s => s + 1);
    setAnswers(a => [...a, { questionIndex: currentQ, selected: idx, correct, hintUsed }]);
    setTotalTime(t => t + (tier.timePerQuestion - timer));
  }, [showExplanation, currentQ, currentQuestion, hintUsed, timer, tier]);

  const nextQuestion = useCallback(() => {
    if (currentQ + 1 >= questions.length) {
      setView(VIEWS.RESULTS);
    } else {
      setCurrentQ(q => q + 1);
      setSelected(null);
      setShowExplanation(false);
      setHintUsed(false);
      setEliminatedOptions([]);
    }
  }, [currentQ, questions.length]);

  const useHint = useCallback(() => {
    if (hintsLeft <= 0 || hintUsed || showExplanation) return;
    setHintUsed(true);
    setHintsLeft(h => h - 1);
    const wrongOptions = [0,1,2,3].filter(i => i !== currentQuestion.answer);
    const toEliminate = wrongOptions.sort(() => Math.random() - 0.5).slice(0, 2);
    setEliminatedOptions(toEliminate);
  }, [hintsLeft, hintUsed, showExplanation, currentQuestion]);

  const startQuiz = useCallback((diff) => {
    setDifficulty(diff);
    setCurrentQ(0);
    setScore(0);
    setAnswers([]);
    setSelected(null);
    setShowExplanation(false);
    setHintsLeft(DIFFICULTY_TIERS[diff].hintAllowed);
    setHintUsed(false);
    setEliminatedOptions([]);
    setTotalTime(0);
    setView(VIEWS.QUIZ);
  }, []);

  const pct = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;
  const grade = pct >= 95 ? "S" : pct >= 85 ? "A" : pct >= 70 ? "B" : pct >= 55 ? "C" : pct >= 40 ? "D" : "F";
  const gradeColor = { S: "#D4AF37", A: "#4CAF50", B: "#8BC34A", C: "#FF9800", D: "#f44336", F: "#b71c1c" }[grade];

  // ─── STYLES ──────────────────────────────────────────────────────

  const S = {
    root: { minHeight: "100vh", background: "#08080c", color: "#e8e4dc", fontFamily: "'DM Sans', sans-serif", position: "relative", overflow: "hidden" },
    container: { maxWidth: 1100, margin: "0 auto", padding: "20px 24px", position: "relative", zIndex: 1 },
    gold: "#D4AF37",
    card: { background: "rgba(18,18,24,0.85)", border: "1px solid rgba(212,175,55,0.15)", borderRadius: 12, padding: 24, backdropFilter: "blur(12px)" },
    btn: (color = "#D4AF37") => ({ background: "transparent", border: `1px solid ${color}`, color, padding: "10px 24px", borderRadius: 8, cursor: "pointer", fontFamily: "'DM Sans', sans-serif", fontSize: 14, fontWeight: 600, transition: "all 0.3s ease" }),
    btnFilled: (color = "#D4AF37") => ({ background: color, border: `1px solid ${color}`, color: "#08080c", padding: "12px 28px", borderRadius: 8, cursor: "pointer", fontFamily: "'DM Sans', sans-serif", fontSize: 15, fontWeight: 700, transition: "all 0.3s ease" }),
  };

  // ─── LANDING ─────────────────────────────────────────────────────

  if (view === VIEWS.LANDING) {
    return (
      <div style={S.root}>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800;900&family=DM+Mono:wght@300;400;500&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap');
          * { box-sizing: border-box; margin: 0; padding: 0; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
          @keyframes pulse { 0%, 100% { opacity: 0.4; } 50% { opacity: 1; } }
          @keyframes slideIn { from { opacity: 0; transform: translateX(-20px); } to { opacity: 1; transform: translateX(0); } }
          @keyframes glitch { 0%, 100% { transform: translate(0); } 20% { transform: translate(-2px, 2px); } 40% { transform: translate(2px, -2px); } 60% { transform: translate(-1px, -1px); } 80% { transform: translate(1px, 1px); } }
          button:hover { transform: translateY(-2px); box-shadow: 0 4px 20px rgba(212,175,55,0.3) !important; }
        `}</style>
        <AnimatedBG />
        <div style={{ ...S.container, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "100vh", textAlign: "center" }}>
          <div style={{ animation: "fadeUp 1s ease", marginBottom: 24 }}>
            <div style={{ fontSize: 13, letterSpacing: 6, color: "rgba(212,175,55,0.6)", fontFamily: "'DM Mono', monospace", marginBottom: 12 }}>GLASS STONE PRESENTS</div>
            <div style={{ fontSize: 11, letterSpacing: 4, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", marginBottom: 32 }}>A FINANCIAL FORENSICS EXAMINATION</div>
          </div>

          <div style={{ animation: "fadeUp 1.2s ease" }}>
            <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(48px, 8vw, 96px)", fontWeight: 900, color: S.gold, lineHeight: 0.95, letterSpacing: -2, marginBottom: 8 }}>
              ENRON
            </h1>
            <div style={{ fontSize: "clamp(14px, 2.5vw, 20px)", letterSpacing: 8, color: "rgba(255,255,255,0.5)", fontFamily: "'DM Mono', monospace", marginBottom: 8 }}>
              THE TEST
            </div>
            <div style={{ width: 60, height: 1, background: "linear-gradient(90deg, transparent, #D4AF37, transparent)", margin: "16px auto" }} />
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", marginBottom: 40 }}>
              POWERED BY CLAUDE SONNET 4.6
            </div>
          </div>

          <div style={{ animation: "fadeUp 1.5s ease", maxWidth: 540, marginBottom: 48 }}>
            <p style={{ fontSize: 16, lineHeight: 1.7, color: "rgba(255,255,255,0.6)", fontWeight: 300 }}>
              $74 billion in shareholder value destroyed. 20,000 jobs lost. The largest corporate fraud in American history.
            </p>
            <p style={{ fontSize: 14, lineHeight: 1.7, color: "rgba(255,255,255,0.4)", fontWeight: 300, marginTop: 12 }}>
              How well do you understand what happened — and why it matters?
            </p>
          </div>

          <div style={{ display: "flex", gap: 16, animation: "fadeUp 1.8s ease", flexWrap: "wrap", justifyContent: "center" }}>
            <button onClick={() => setView(VIEWS.SELECT)} style={S.btnFilled()}>BEGIN TEST</button>
            <button onClick={() => setView(VIEWS.DATA)} style={S.btn()}>FINANCIAL DATA</button>
            <button onClick={() => setView(VIEWS.TIMELINE)} style={S.btn()}>TIMELINE</button>
          </div>

          <div style={{ marginTop: 64, animation: "fadeUp 2.2s ease", display: "flex", gap: 32, flexWrap: "wrap", justifyContent: "center" }}>
            {[
              { n: "$90.75", l: "Peak Stock" },
              { n: "$0.26", l: "Final Price" },
              { n: "$74B", l: "Value Lost" },
              { n: "20,000", l: "Jobs Lost" },
            ].map((s, i) => (
              <div key={i} style={{ textAlign: "center" }}>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 24, color: S.gold, fontWeight: 700 }}>{s.n}</div>
                <div style={{ fontSize: 10, letterSpacing: 2, color: "rgba(255,255,255,0.35)", marginTop: 4 }}>{s.l}</div>
              </div>
            ))}
          </div>

          <div style={{ position: "absolute", bottom: 20, fontSize: 10, color: "rgba(255,255,255,0.2)", fontFamily: "'DM Mono', monospace", letterSpacing: 2 }}>
            GLASS STONE © 2026 — CEO GABRIEL B. RODRIGUEZ
          </div>
        </div>
      </div>
    );
  }

  // ─── DIFFICULTY SELECT ───────────────────────────────────────────

  if (view === VIEWS.SELECT) {
    return (
      <div style={S.root}>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800;900&family=DM+Mono:wght@300;400;500&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap');
          * { box-sizing: border-box; margin: 0; padding: 0; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
          button:hover { transform: translateY(-2px) !important; }
        `}</style>
        <AnimatedBG />
        <div style={S.container}>
          <button onClick={() => setView(VIEWS.LANDING)} style={{ ...S.btn("rgba(255,255,255,0.4)"), marginBottom: 32, fontSize: 12 }}>← BACK</button>

          <div style={{ textAlign: "center", marginBottom: 40 }}>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 36, color: S.gold, fontWeight: 800 }}>SELECT DIFFICULTY</h2>
            <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 13, marginTop: 8 }}>Each tier is named after a key figure in the Enron scandal</p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 20 }}>
            {Object.entries(DIFFICULTY_TIERS).map(([key, t], i) => (
              <div key={key} onClick={() => startQuiz(key)} style={{
                ...S.card, cursor: "pointer", borderColor: t.border, background: t.bg,
                animation: `fadeUp ${0.5 + i * 0.15}s ease`, transition: "all 0.3s ease",
                display: "flex", flexDirection: "column"
              }}
              onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = `0 8px 32px ${t.color}33`; }}
              onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                  <span style={{ fontSize: 36 }}>{t.icon}</span>
                  <span style={{ fontSize: 10, letterSpacing: 3, color: t.color, fontFamily: "'DM Mono', monospace", fontWeight: 700, padding: "4px 12px", border: `1px solid ${t.border}`, borderRadius: 4 }}>{t.level}</span>
                </div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#fff", fontWeight: 700, marginBottom: 4 }}>{t.name}</h3>
                <div style={{ fontSize: 12, color: t.color, fontFamily: "'DM Mono', monospace", marginBottom: 4 }}>{t.title}</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", fontStyle: "italic", marginBottom: 12 }}>{t.subtitle}</div>
                <p style={{ fontSize: 13, lineHeight: 1.6, color: "rgba(255,255,255,0.5)", flex: 1 }}>{t.description}</p>
                <div style={{ borderTop: `1px solid ${t.border}`, marginTop: 16, paddingTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, fontSize: 11, fontFamily: "'DM Mono', monospace" }}>
                  <div><span style={{ color: "rgba(255,255,255,0.35)" }}>TIME</span><br /><span style={{ color: t.color }}>{t.timePerQuestion}s</span></div>
                  <div><span style={{ color: "rgba(255,255,255,0.35)" }}>HINTS</span><br /><span style={{ color: t.color }}>{t.hintAllowed}</span></div>
                  <div><span style={{ color: "rgba(255,255,255,0.35)" }}>Q's</span><br /><span style={{ color: t.color }}>{t.questionCount}</span></div>
                </div>
                <div style={{ marginTop: 12, fontSize: 11, color: "rgba(255,255,255,0.3)", lineHeight: 1.5, fontStyle: "italic" }}>
                  Fate: {t.fate}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ─── FINANCIAL DATA ──────────────────────────────────────────────

  if (view === VIEWS.DATA) {
    const COMP_COLORS = ["#D4AF37", "#f44336", "#FF9800", "#4CAF50", "#2196F3"];
    return (
      <div style={S.root}>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800;900&family=DM+Mono:wght@300;400;500&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap');
          * { box-sizing: border-box; margin: 0; padding: 0; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
          button:hover { opacity: 0.85; }
        `}</style>
        <AnimatedBG />
        <div style={S.container}>
          <button onClick={() => setView(VIEWS.LANDING)} style={{ ...S.btn("rgba(255,255,255,0.4)"), marginBottom: 24, fontSize: 12 }}>← BACK</button>

          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 32, color: S.gold, fontWeight: 800, textAlign: "center", marginBottom: 8 }}>ENRON FINANCIAL DATA</h2>
          <p style={{ textAlign: "center", color: "rgba(255,255,255,0.4)", fontSize: 13, marginBottom: 24 }}>Real historical data from SEC filings, congressional investigations, and court documents</p>

          <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 24, flexWrap: "wrap" }}>
            {[
              { key: "stock", label: "STOCK PRICE" },
              { key: "revenue", label: "REVENUE" },
              { key: "debt", label: "HIDDEN DEBT" },
              { key: "spe", label: "SPE LOSSES" },
              { key: "comp", label: "EXEC COMPENSATION" },
            ].map(t => (
              <button key={t.key} onClick={() => setDataTab(t.key)}
                style={{ ...S.btn(dataTab === t.key ? S.gold : "rgba(255,255,255,0.3)"), fontSize: 11, padding: "8px 16px", background: dataTab === t.key ? "rgba(212,175,55,0.15)" : "transparent" }}>
                {t.label}
              </button>
            ))}
          </div>

          <div style={{ ...S.card, animation: "fadeUp 0.4s ease" }}>
            {dataTab === "stock" && (
              <>
                <h3 style={{ fontFamily: "'DM Mono', monospace", fontSize: 14, color: S.gold, marginBottom: 4 }}>ENRON CORP (ENE) — STOCK PRICE HISTORY</h3>
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 16 }}>Peak $90.75 (Aug 2000) → $0.26 (Dec 2001) — 99.7% decline</p>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={STOCK_DATA}>
                    <defs>
                      <linearGradient id="stockGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#D4AF37" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="year" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} />
                    <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} tickFormatter={v => `$${v}`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="price" stroke="#D4AF37" fill="url(#stockGrad)" strokeWidth={2} name="Close Price" />
                    <Area type="monotone" dataKey="high" stroke="#4CAF50" fill="none" strokeWidth={1} strokeDasharray="4 4" name="High" />
                    <Area type="monotone" dataKey="low" stroke="#f44336" fill="none" strokeWidth={1} strokeDasharray="4 4" name="Low" />
                    <Legend wrapperStyle={{ fontSize: 11, fontFamily: "'DM Mono', monospace" }} />
                  </AreaChart>
                </ResponsiveContainer>
              </>
            )}

            {dataTab === "revenue" && (
              <>
                <h3 style={{ fontFamily: "'DM Mono', monospace", fontSize: 14, color: S.gold, marginBottom: 4 }}>REPORTED REVENUE ($B)</h3>
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 16 }}>Revenue grew 660% in 5 years — much of it from mark-to-market accounting on trading contracts</p>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={REVENUE_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="year" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
                    <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} tickFormatter={v => `$${v}B`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="revenue" fill="#D4AF37" radius={[4, 4, 0, 0]} name="Reported Revenue" />
                  </BarChart>
                </ResponsiveContainer>
              </>
            )}

            {dataTab === "debt" && (
              <>
                <h3 style={{ fontFamily: "'DM Mono', monospace", fontSize: 14, color: S.gold, marginBottom: 4 }}>DISCLOSED vs HIDDEN DEBT ($B)</h3>
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 16 }}>By 2001, nearly as much debt was hidden off-balance-sheet through SPEs as was publicly disclosed</p>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={DEBT_HIDDEN}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="year" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} />
                    <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} tickFormatter={v => `$${v}B`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="disclosed" fill="#D4AF37" radius={[4, 4, 0, 0]} name="Disclosed Debt" />
                    <Bar dataKey="hidden" fill="#f44336" radius={[4, 4, 0, 0]} name="Hidden Debt (SPEs)" />
                    <Legend wrapperStyle={{ fontSize: 11, fontFamily: "'DM Mono', monospace" }} />
                  </BarChart>
                </ResponsiveContainer>
              </>
            )}

            {dataTab === "spe" && (
              <>
                <h3 style={{ fontFamily: "'DM Mono', monospace", fontSize: 14, color: S.gold, marginBottom: 4 }}>SPE LOSSES BY ENTITY ($M)</h3>
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 16 }}>Estimated losses absorbed or hidden by each major Special Purpose Entity</p>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={SPE_DATA} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis type="number" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} tickFormatter={v => `$${v}M`} />
                    <YAxis dataKey="name" type="category" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 12, fontFamily: "'DM Mono', monospace" }} width={100} />
                    <Tooltip content={({ active, payload }) => active && payload?.[0] ? (
                      <div style={{ background: "rgba(10,10,15,0.95)", border: "1px solid rgba(212,175,55,0.4)", borderRadius: 8, padding: "10px 14px", fontFamily: "'DM Mono', monospace", fontSize: 12 }}>
                        <p style={{ color: "#D4AF37", margin: 0, fontWeight: 700 }}>{payload[0].payload.name}</p>
                        <p style={{ color: "#f44336", margin: "4px 0 0" }}>Losses: ${payload[0].value}M</p>
                        <p style={{ color: "rgba(255,255,255,0.5)", margin: "4px 0 0" }}>Created: {payload[0].payload.created}</p>
                      </div>
                    ) : null} />
                    <Bar dataKey="losses" fill="#f44336" radius={[0, 4, 4, 0]} name="Estimated Losses" />
                  </BarChart>
                </ResponsiveContainer>
              </>
            )}

            {dataTab === "comp" && (
              <>
                <h3 style={{ fontFamily: "'DM Mono', monospace", fontSize: 14, color: S.gold, marginBottom: 4 }}>EXECUTIVE COMPENSATION & STOCK SALES ($M)</h3>
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 16 }}>Total compensation and insider stock sales 1998–2001 (pre-collapse)</p>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={EXECUTIVE_COMPENSATION}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }} />
                    <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} tickFormatter={v => `$${v}M`} />
                    <Tooltip content={({ active, payload }) => active && payload?.[0] ? (
                      <div style={{ background: "rgba(10,10,15,0.95)", border: "1px solid rgba(212,175,55,0.4)", borderRadius: 8, padding: "10px 14px", fontFamily: "'DM Mono', monospace", fontSize: 12 }}>
                        <p style={{ color: "#D4AF37", margin: 0, fontWeight: 700 }}>{payload[0].payload.name}</p>
                        <p style={{ color: "#4CAF50", margin: "4px 0 0" }}>Salary/Bonus: ${payload[0].payload.salary}M</p>
                        <p style={{ color: "#FF9800", margin: "4px 0 0" }}>Stock Sales: ${payload[0].payload.stockSales}M</p>
                        <p style={{ color: "#f44336", margin: "4px 0 0", fontWeight: 700 }}>Total: ${payload[0].payload.total}M</p>
                      </div>
                    ) : null} />
                    <Bar dataKey="salary" stackId="a" fill="#4CAF50" name="Salary/Bonus" />
                    <Bar dataKey="stockSales" stackId="a" fill="#FF9800" radius={[4, 4, 0, 0]} name="Stock Sales" />
                    <Legend wrapperStyle={{ fontSize: 11, fontFamily: "'DM Mono', monospace" }} />
                  </BarChart>
                </ResponsiveContainer>
              </>
            )}
          </div>

          <div style={{ textAlign: "center", marginTop: 20, fontSize: 10, color: "rgba(255,255,255,0.25)", fontFamily: "'DM Mono', monospace" }}>
            Sources: SEC filings, Senate Permanent Subcommittee on Investigations, Powers Report, Batson Report, court documents
          </div>
        </div>
      </div>
    );
  }

  // ─── TIMELINE ────────────────────────────────────────────────────

  if (view === VIEWS.TIMELINE) {
    const catColors = { corporate: "#4CAF50", accounting: "#FF9800", fraud: "#f44336", media: "#2196F3", political: "#9C27B0", peak: "#D4AF37", collapse: "#b71c1c", whistleblower: "#00BCD4", aftermath: "#795548", legal: "#607D8B" };
    return (
      <div style={S.root}>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800;900&family=DM+Mono:wght@300;400;500&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap');
          * { box-sizing: border-box; margin: 0; padding: 0; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
          button:hover { opacity: 0.85; }
        `}</style>
        <AnimatedBG />
        <div style={S.container}>
          <button onClick={() => setView(VIEWS.LANDING)} style={{ ...S.btn("rgba(255,255,255,0.4)"), marginBottom: 24, fontSize: 12 }}>← BACK</button>

          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 32, color: S.gold, fontWeight: 800, textAlign: "center", marginBottom: 8 }}>THE ENRON TIMELINE</h2>
          <p style={{ textAlign: "center", color: "rgba(255,255,255,0.4)", fontSize: 13, marginBottom: 8 }}>1985 — 2006: From formation to final sentencing</p>
          <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 24, flexWrap: "wrap" }}>
            {Object.entries(catColors).map(([cat, color]) => (
              <span key={cat} style={{ fontSize: 10, color, fontFamily: "'DM Mono', monospace", letterSpacing: 1, textTransform: "uppercase" }}>● {cat}</span>
            ))}
          </div>

          <div style={{ position: "relative", paddingLeft: 32 }}>
            <div style={{ position: "absolute", left: 12, top: 0, bottom: 0, width: 2, background: "linear-gradient(to bottom, rgba(212,175,55,0.4), rgba(183,28,28,0.6), rgba(96,125,139,0.4))" }} />
            {TIMELINE_EVENTS.map((ev, i) => (
              <div key={i} style={{ position: "relative", marginBottom: 16, animation: `fadeUp ${0.3 + i * 0.04}s ease` }}>
                <div style={{ position: "absolute", left: -26, top: 6, width: 12, height: 12, borderRadius: "50%", background: catColors[ev.category] || "#fff", border: "2px solid #08080c", boxShadow: `0 0 8px ${catColors[ev.category]}44` }} />
                <div style={{ ...S.card, padding: "12px 16px", borderColor: `${catColors[ev.category]}33` }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                    <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 13, color: catColors[ev.category], fontWeight: 700 }}>
                      {Math.floor(ev.year)}
                    </span>
                    <span style={{ fontSize: 9, letterSpacing: 2, color: catColors[ev.category], textTransform: "uppercase", fontFamily: "'DM Mono', monospace" }}>{ev.category}</span>
                  </div>
                  <p style={{ fontSize: 13, lineHeight: 1.6, color: "rgba(255,255,255,0.7)" }}>{ev.event}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ─── QUIZ ────────────────────────────────────────────────────────

  if (view === VIEWS.QUIZ && currentQuestion) {
    const progress = ((currentQ + 1) / questions.length) * 100;
    const timerPct = tier ? (timer / tier.timePerQuestion) * 100 : 100;
    const timerColor = timerPct > 50 ? "#4CAF50" : timerPct > 25 ? "#FF9800" : "#f44336";
    return (
      <div style={S.root}>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800;900&family=DM+Mono:wght@300;400;500&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap');
          * { box-sizing: border-box; margin: 0; padding: 0; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
          @keyframes pulse { 0%, 100% { opacity: 0.6; } 50% { opacity: 1; } }
          button:hover { transform: translateY(-1px) !important; }
        `}</style>
        <AnimatedBG />
        <div style={S.container}>
          {/* Header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div>
              <span style={{ fontSize: 11, color: tier.color, fontFamily: "'DM Mono', monospace", letterSpacing: 2 }}>{tier.icon} {tier.name.toUpperCase()} — {tier.level}</span>
            </div>
            <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
              {hintsLeft > 0 && !showExplanation && (
                <button onClick={useHint} disabled={hintUsed} style={{ ...S.btn("#FF9800"), fontSize: 11, padding: "6px 14px", opacity: hintUsed ? 0.3 : 1, cursor: hintUsed ? "default" : "pointer" }}>
                  💡 HINT ({hintsLeft})
                </button>
              )}
              <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 13, color: S.gold }}>{score}/{currentQ + (showExplanation ? 1 : 0)}</span>
            </div>
          </div>

          {/* Progress */}
          <div style={{ height: 3, background: "rgba(255,255,255,0.08)", borderRadius: 2, marginBottom: 8, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${progress}%`, background: tier.color, transition: "width 0.5s ease", borderRadius: 2 }} />
          </div>

          {/* Timer */}
          <div style={{ height: 3, background: "rgba(255,255,255,0.05)", borderRadius: 2, marginBottom: 24, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${timerPct}%`, background: timerColor, transition: "width 1s linear", borderRadius: 2, animation: timerPct < 25 ? "pulse 0.5s infinite" : "none" }} />
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 24, fontSize: 11, fontFamily: "'DM Mono', monospace" }}>
            <span style={{ color: "rgba(255,255,255,0.4)" }}>Q{currentQ + 1} of {questions.length}</span>
            <span style={{ color: "rgba(255,255,255,0.3)" }}>{currentQuestion.category}</span>
            <span style={{ color: timerColor, fontWeight: 700, fontSize: 16 }}>{timer}s</span>
          </div>

          {/* Question */}
          <div style={{ ...S.card, marginBottom: 20, animation: "fadeUp 0.3s ease" }}>
            <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, color: "#fff", fontWeight: 600, lineHeight: 1.5 }}>
              {currentQuestion.q}
            </h3>
          </div>

          {/* Options */}
          <div style={{ display: "grid", gap: 12, marginBottom: 20 }}>
            {currentQuestion.options.map((opt, i) => {
              const isEliminated = eliminatedOptions.includes(i);
              const isSelected = selected === i;
              const isCorrect = i === currentQuestion.answer;
              let bg = "rgba(18,18,24,0.85)";
              let border = "rgba(255,255,255,0.1)";
              let textColor = "rgba(255,255,255,0.8)";

              if (showExplanation) {
                if (isCorrect) { bg = "rgba(76,175,80,0.15)"; border = "#4CAF50"; textColor = "#4CAF50"; }
                else if (isSelected && !isCorrect) { bg = "rgba(244,67,54,0.15)"; border = "#f44336"; textColor = "#f44336"; }
              }

              if (isEliminated) { bg = "rgba(18,18,24,0.4)"; textColor = "rgba(255,255,255,0.15)"; }

              return (
                <button key={i} onClick={() => !showExplanation && !isEliminated && handleAnswer(i)}
                  disabled={showExplanation || isEliminated}
                  style={{
                    background: bg, border: `1px solid ${border}`, borderRadius: 10, padding: "14px 18px",
                    textAlign: "left", cursor: showExplanation || isEliminated ? "default" : "pointer",
                    color: textColor, fontFamily: "'DM Sans', sans-serif", fontSize: 14, lineHeight: 1.5,
                    transition: "all 0.2s ease", display: "flex", alignItems: "center", gap: 12,
                    textDecoration: isEliminated ? "line-through" : "none"
                  }}>
                  <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 12, color: showExplanation && isCorrect ? "#4CAF50" : "rgba(255,255,255,0.3)", minWidth: 24 }}>
                    {showExplanation ? (isCorrect ? "✓" : isSelected ? "✗" : " ") : String.fromCharCode(65 + i)}
                  </span>
                  {opt}
                </button>
              );
            })}
          </div>

          {/* Explanation */}
          {showExplanation && (
            <div style={{ ...S.card, borderColor: "rgba(212,175,55,0.3)", animation: "fadeUp 0.3s ease", marginBottom: 20 }}>
              <div style={{ fontSize: 11, letterSpacing: 2, color: S.gold, fontFamily: "'DM Mono', monospace", marginBottom: 8 }}>EXPLANATION</div>
              <p style={{ fontSize: 14, lineHeight: 1.7, color: "rgba(255,255,255,0.7)" }}>{currentQuestion.explanation}</p>
            </div>
          )}

          {showExplanation && (
            <div style={{ textAlign: "center" }}>
              <button onClick={nextQuestion} style={S.btnFilled(tier.color)}>
                {currentQ + 1 >= questions.length ? "VIEW RESULTS" : "NEXT QUESTION →"}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ─── RESULTS ─────────────────────────────────────────────────────

  if (view === VIEWS.RESULTS) {
    const avgTime = answers.length > 0 ? (totalTime / answers.length).toFixed(1) : 0;
    const categoryStats = {};
    answers.forEach((a, i) => {
      const cat = questions[i]?.category;
      if (!categoryStats[cat]) categoryStats[cat] = { correct: 0, total: 0 };
      categoryStats[cat].total++;
      if (a.correct) categoryStats[cat].correct++;
    });
    const radarData = Object.entries(categoryStats).map(([cat, stats]) => ({
      category: cat, score: Math.round((stats.correct / stats.total) * 100), fullMark: 100
    }));

    const verdicts = {
      S: { title: "FORENSIC EXPERT", msg: "You see through every layer of the fraud. Sherron Watkins would be proud.", emoji: "🏆" },
      A: { title: "SENIOR INVESTIGATOR", msg: "Deep understanding of the mechanics and context. You would have caught this.", emoji: "🔍" },
      B: { title: "FINANCIAL ANALYST", msg: "Solid grasp of the story. A few blind spots in the details.", emoji: "📊" },
      C: { title: "BUSINESS REPORTER", msg: "You know the headlines but miss the mechanics underneath.", emoji: "📰" },
      D: { title: "WALL STREET INTERN", msg: "The basics are shaky. This is how fraud goes undetected.", emoji: "📋" },
      F: { title: "ENRON BOARD MEMBER", msg: "You approved everything without understanding anything. Exactly the problem.", emoji: "🤦" },
    };
    const verdict = verdicts[grade];

    return (
      <div style={S.root}>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800;900&family=DM+Mono:wght@300;400;500&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap');
          * { box-sizing: border-box; margin: 0; padding: 0; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
          @keyframes scaleIn { from { opacity: 0; transform: scale(0.5); } to { opacity: 1; transform: scale(1); } }
          button:hover { transform: translateY(-2px) !important; }
        `}</style>
        <AnimatedBG />
        <div style={S.container}>
          <div style={{ textAlign: "center", marginBottom: 32, animation: "fadeUp 0.5s ease" }}>
            <div style={{ fontSize: 48, marginBottom: 8 }}>{verdict.emoji}</div>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 36, color: S.gold, fontWeight: 800 }}>TEST COMPLETE</h2>
            <p style={{ color: tier?.color, fontSize: 12, fontFamily: "'DM Mono', monospace", letterSpacing: 3, marginTop: 4 }}>{tier?.icon} {tier?.name.toUpperCase()} — {tier?.level}</p>
          </div>

          {/* Grade */}
          <div style={{ textAlign: "center", marginBottom: 32, animation: "scaleIn 0.8s ease" }}>
            <div style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 120, height: 120, borderRadius: "50%", border: `4px solid ${gradeColor}`, background: `${gradeColor}15` }}>
              <span style={{ fontFamily: "'Playfair Display', serif", fontSize: 64, fontWeight: 900, color: gradeColor }}>{grade}</span>
            </div>
            <div style={{ marginTop: 12, fontFamily: "'DM Mono', monospace", fontSize: 14, color: gradeColor, letterSpacing: 3 }}>{verdict.title}</div>
            <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", marginTop: 8, maxWidth: 400, margin: "8px auto 0" }}>{verdict.msg}</p>
          </div>

          {/* Stats */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12, marginBottom: 24, animation: "fadeUp 0.6s ease" }}>
            {[
              { label: "CORRECT", value: `${score}/${questions.length}`, color: "#4CAF50" },
              { label: "ACCURACY", value: `${pct}%`, color: S.gold },
              { label: "AVG TIME", value: `${avgTime}s`, color: "#2196F3" },
              { label: "TOTAL TIME", value: `${Math.round(totalTime)}s`, color: "#FF9800" },
            ].map((s, i) => (
              <div key={i} style={{ ...S.card, textAlign: "center", padding: 16 }}>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 28, color: s.color, fontWeight: 700 }}>{s.value}</div>
                <div style={{ fontSize: 10, letterSpacing: 2, color: "rgba(255,255,255,0.35)", marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Radar */}
          {radarData.length > 2 && (
            <div style={{ ...S.card, marginBottom: 24, animation: "fadeUp 0.8s ease" }}>
              <h3 style={{ fontFamily: "'DM Mono', monospace", fontSize: 12, color: S.gold, marginBottom: 16, letterSpacing: 2 }}>CATEGORY BREAKDOWN</h3>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="rgba(255,255,255,0.1)" />
                  <PolarAngleAxis dataKey="category" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 10 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 9 }} />
                  <Radar name="Score" dataKey="score" stroke={tier?.color || S.gold} fill={tier?.color || S.gold} fillOpacity={0.2} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Question Review */}
          <div style={{ ...S.card, animation: "fadeUp 1s ease", marginBottom: 24 }}>
            <h3 style={{ fontFamily: "'DM Mono', monospace", fontSize: 12, color: S.gold, marginBottom: 16, letterSpacing: 2 }}>QUESTION REVIEW</h3>
            {answers.map((a, i) => (
              <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "10px 0", borderBottom: i < answers.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 16, color: a.correct ? "#4CAF50" : "#f44336", minWidth: 20 }}>
                  {a.correct ? "✓" : "✗"}
                </span>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginBottom: 4 }}>{questions[i]?.q}</p>
                  {!a.correct && (
                    <p style={{ fontSize: 11, color: "#4CAF50", fontFamily: "'DM Mono', monospace" }}>
                      Correct: {questions[i]?.options[questions[i]?.answer]}
                    </p>
                  )}
                </div>
                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace" }}>{questions[i]?.category}</span>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", animation: "fadeUp 1.2s ease" }}>
            <button onClick={() => startQuiz(difficulty)} style={S.btnFilled(tier?.color)}>RETRY {tier?.level}</button>
            <button onClick={() => setView(VIEWS.SELECT)} style={S.btn()}>CHANGE DIFFICULTY</button>
            <button onClick={() => setView(VIEWS.LANDING)} style={S.btn("rgba(255,255,255,0.4)")}>HOME</button>
          </div>

          <div style={{ textAlign: "center", marginTop: 40, fontSize: 10, color: "rgba(255,255,255,0.2)", fontFamily: "'DM Mono', monospace", letterSpacing: 2 }}>
            ENRON TEST — CLAUDE SONNET 4.6 — GLASS STONE © 2026 — CEO GABRIEL B. RODRIGUEZ
          </div>
        </div>
      </div>
    );
  }

  return null;
}
