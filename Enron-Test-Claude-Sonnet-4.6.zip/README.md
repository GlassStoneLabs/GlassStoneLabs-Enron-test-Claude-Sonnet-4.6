# ENRON TEST — Claude Sonnet 4.6

<p align="center">
  <strong>A Financial Forensics Examination</strong><br/>
  <em>$74 billion lost. 20,000 jobs destroyed. How well do you understand what happened?</em>
</p>

---

## Overview

**Enron Test** is a fully functional, interactive financial knowledge examination built as a single React component. It tests understanding of the Enron Corporation scandal — the largest corporate fraud in American history — through historically accurate questions, real financial data visualizations, and a comprehensive timeline spanning 1985 to 2006.

This is not a demo. It is a complete, functional application.

---

## Features

### 🎯 Four Difficulty Tiers (Named After Key Figures)

| Tier | Character | Level | Questions | Time/Q | Hints |
|------|-----------|-------|-----------|--------|-------|
| 🎩 | **Ken Lay** — Chairman & CEO | EASY | 12 | 45s | 3 |
| 📊 | **Andy Fastow** — CFO | MEDIUM | 15 | 35s | 2 |
| 🧠 | **Jeff Skilling** — President & CEO | HARD | 18 | 25s | 1 |
| 🔍 | **Sherron Watkins** — VP / Whistleblower | EXPERT | 20 | 20s | 0 |

Each tier includes the real fate of the person it's named after.

### 📊 Real Financial Data Visualizations

All data sourced from SEC filings, congressional investigations, the Powers Report, and the Batson Report:

- **Stock Price History** (1990–Dec 2001) — Peak $90.75 → $0.26
- **Revenue Growth** (1996–2001) — $13.3B → $138.7B
- **Disclosed vs Hidden Debt** — Showing off-balance-sheet obligations through SPEs
- **SPE Loss Breakdown** — LJM1, LJM2, Raptor, Chewco, JEDI, Whitewing
- **Executive Compensation** — Salary, stock sales, and total enrichment before collapse

### 📅 Complete Timeline

26+ events from 1985 (formation) through 2006 (final sentencing), color-coded by category:
- Corporate milestones
- Accounting manipulation events
- Fraud creation dates
- Political connections and legislation
- The collapse sequence (Aug–Dec 2001)
- Legal aftermath and sentencing

### 🎨 Dynamic Graphics

- Animated particle network background (canvas-based, scales to any viewport)
- Recharts-powered interactive charts (Area, Bar, Radar, responsive)
- Frosted glass card system with difficulty-tier color coding
- Real-time timer with color-coded urgency states
- Progress tracking with animated bars
- Grade system: S / A / B / C / D / F with verdict titles
- Category-specific performance radar chart on results
- Full question review with correct answer display

### 🧠 65 Historically Accurate Questions

Covering:
- Corporate history and key figures
- Mark-to-market accounting mechanics
- SPE structures (LJM, Raptor, Chewco, JEDI)
- California energy market manipulation (Death Star, Fat Boy)
- Political connections (Phil Gramm, Commodity Futures Modernization Act)
- Regulatory failures and the "Enron Loophole"
- Sarbanes-Oxley Act provisions
- Arthur Andersen's destruction
- Whistleblower timeline
- Legal outcomes and sentencing
- Systemic implications (rules-based vs principles-based accounting)
- Technical accounting (FAS 140, total-return swaps, gain-on-sale)

Every question includes a detailed explanation citing the specific historical context.

---

## Technical Stack

- **React** (functional components with hooks)
- **Recharts** (data visualization)
- **Canvas API** (animated background)
- **Google Fonts** (DM Sans, DM Mono, Playfair Display)
- **Single-file architecture** — fully self-contained JSX

No external API calls. No database. No backend. All data is embedded.

---

## How to Run

### Option 1: Claude Artifact
Drop `EnronTest.jsx` into any Claude.ai conversation as a React artifact.

### Option 2: Local React Project
```bash
npx create-react-app enron-test
cd enron-test
npm install recharts
# Replace src/App.js content with EnronTest.jsx
npm start
```

### Option 3: Vite
```bash
npm create vite@latest enron-test -- --template react
cd enron-test
npm install recharts
# Copy EnronTest.jsx to src/ and import in main.jsx
npm run dev
```

---

## Disclaimer

> **Time Investment**: This application was designed, researched, and coded in a single session by Claude Sonnet 4.6 (Anthropic) under the direction of Gabriel B. Rodriguez, CEO of Glass Stone. The historical data, financial figures, questions, explanations, and timeline events are based on Claude's training knowledge of publicly available information from SEC filings, congressional testimony, court documents, the Powers Report, the Batson Report, and published investigative journalism (including *The Smartest Guys in the Room* by Bethany McLean and Peter Elkind).
>
> **Accuracy Note**: While every effort has been made to ensure historical accuracy, some figures (particularly estimated losses, hidden debt totals, and compensation figures) represent ranges reported across multiple sources and may vary by source. This application is intended for **educational purposes only** and does not constitute financial, legal, or investment advice.
>
> **No Affiliation**: This project is not affiliated with, endorsed by, or connected to Enron Corp (defunct), any of the individuals named in the test, Arthur Andersen LLP, or any government agency involved in the Enron investigation.

---

## Credits

**Built by**: Glass Stone  
**CEO**: Gabriel B. Rodriguez  
**AI Engine**: Claude Sonnet 4.6 (Anthropic)  
**Year**: 2026  

---

## License

Educational use. Glass Stone © 2026. All rights reserved.

---

<p align="center">
  <em>"The Enron scandal is not just a story about greed — it's a story about what happens when systems of accountability fail at every level simultaneously."</em>
</p>
