# ENRON: MELTDOWN MANAGER — Claude Sonnet 4.6 Edition

<p align="center">
  <strong>A Satirical Corporate Survival Simulator</strong><br/>
  <em>Manage a failing nuclear reactor and a fraudulent financial portfolio simultaneously.</em>
</p>

---

## Overview

**Enron: Meltdown Manager** is a fully functional 3D simulation game built as a single React component. You play as an Enron executive managing a nuclear power plant while simultaneously committing corporate fraud — balancing reactor physics, grid stability, and an increasingly precarious financial house of cards.

Based on real Enron historical events from January 2000 through the December 2001 bankruptcy.

**This is not a demo. It is a complete, functional game.**

---

## Game Systems

### 🔬 Nuclear Reactor Physics
- **Core Temperature** — Heat generation from reactivity, cooling from flow rate and condenser
- **Pressure** — Builds from temperature, released through steam valve to drive turbine
- **Xenon Poisoning** — Neutron-absorbing xenon buildup from fission products
- **Reactivity** — Function of control rod position, xenon, and temperature feedback
- **Meltdown Progress** — Exceeding critical thresholds triggers progressive core failure
- **Grid Frequency** — Must maintain ~60Hz by balancing supply and demand
- **Component Degradation** — Pump, turbine, and condenser health degrade under stress

### 💰 Financial Fraud Mechanics
- **Mark-to-Market Accounting** — Book future profits immediately (+$5K cash, +$6K unrealized losses)
- **Special Purpose Entities (SPEs)** — Create LJM-style partnerships to hide debt off-balance-sheet
- **SPE Collapse** — When stock drops below trigger price, hidden debt returns to books
- **Audit Risk** — Accumulates from SPE count, regulatory aggression, and chapter modifiers
- **Lobbying** — Campaign donations reduce audit risk and provide temporary regulatory shield
- **Document Shredding** — Emergency risk reduction at $3K per shred
- **Loans** — Take $5K loans with 1% daily compounding interest
- **Unrealized Loss Bleed** — Mark-to-market losses gradually become real debt

### 📅 Historical Events (17 Real Events)
Triggered on their actual dates from the Enron timeline:
- Enron Broadband announced (Jan 2000)
- California Energy Crisis begins (May 2000)
- Blockbuster VOD deal (Jul 2000)
- Stock hits ATH $90.56 (Aug 2000)
- Skilling named CEO (Dec 2000)
- Blockbuster deal cancelled (Mar 2001)
- FERC price caps (Jun 2001)
- Skilling resigns (Aug 2001)
- Sherron Watkins memo (Aug 2001)
- September 11 attacks (Sep 2001)
- Q3 $618M loss (Oct 2001)
- SEC inquiry (Oct 2001)
- Fastow fired (Oct 2001)
- Earnings restated (Nov 2001)
- Dynegy merger fails (Nov 2001)
- Chapter 11 bankruptcy (Dec 2001)

### 🎮 4 Chapters
1. **The Vision** (Early 2000) — Establish operations, grow stock
2. **The California Crisis** (Late 2000) — Exploit deregulation, price gouge during brownouts
3. **Creative Accounting** (2001) — Hide mounting debt with SPEs
4. **The Collapse** (Late 2001) — Extract maximum offshore wealth before indictment

### 🎯 4 Difficulty Tiers

| Tier | Character | Level | Starting Cash | Risk Multiplier | Revenue |
|------|-----------|-------|---------------|-----------------|---------|
| 🎩 | Ken Lay | EASY | $8,000 | 0.5× | 1.5× |
| 📊 | Andy Fastow | MEDIUM | $5,000 | 1.0× | 1.0× |
| 🧠 | Jeff Skilling | HARD | $3,000 | 1.5× | 0.8× |
| 🔍 | Sherron Watkins | NIGHTMARE | $2,000 | 2.0× | 0.6× |

---

## Technical Stack

- **3D Rendering**: Three.js r128 (instanced voxel geometry, dynamic lighting, camera orbit)
- **UI Framework**: React with Hooks
- **Charts**: Recharts (real-time stock price and audit risk)
- **Icons**: Lucide React
- **Audio**: Web Audio API (reactor hum, ambient drone, SFX)
- **AI**: Anthropic Claude API for dynamic corporate spin-doctoring
- **Architecture**: Single self-contained JSX file

### 3D Scene Features
- Instanced voxel reactor complex with containment dome (cutaway view)
- Cooling tower
- City skyline with glass/steel buildings
- Power line infrastructure with dynamic color pulsing based on load
- Day/night cycle with sun position tracking
- Dynamic core glow intensity based on temperature and power output
- Camera shake during meltdown conditions
- Fog and sky color changes with weather

### Audio Engine
- Persistent industrial drone (filtered sawtooth LFO)
- Dynamic reactor hum (frequency/volume tracks power and stress)
- Distinct SFX: alarm, cash register, shredder, repair, error, explosion

---

## How to Run

### Option 1: Claude Artifact
Drop `EnronMeltdownManager.jsx` into Claude.ai as a React artifact.

### Option 2: Local Dev
```bash
npm create vite@latest enron-meltdown -- --template react
cd enron-meltdown
npm install three recharts lucide-react
# Copy EnronMeltdownManager.jsx to src/ and import in main.jsx
npm run dev
```

---

## Controls

| Control | Function |
|---------|----------|
| Control Rods slider | 0% = full power, 100% = shutdown |
| Steam Valve slider | Controls turbine speed and power output |
| SCRAM button | Emergency shutdown (rods to 100%) |
| PULL button | Maximum power (rods to 0%) |
| Maintenance tab | Repair pump, turbine, condenser |
| Finance tab | Cash, loans, debt overview |
| Fraud tab | Mark-to-market, SPEs, lobbying, shredding |
| 🔊 button | Get AI-generated corporate spin from Claude |
| Click + drag on 3D scene | Orbit camera |

---

## Disclaimer

> **Time Investment**: This application was designed and coded in a single session by Claude Sonnet 4.6 (Anthropic) under the direction of Gabriel B. Rodriguez, CEO of Glass Stone. Rebuilt from original TypeScript/Vite multi-file architecture into a single self-contained JSX artifact with all game systems preserved.
>
> **Satirical Purpose**: This game is a satirical educational tool about corporate fraud. All financial mechanics (mark-to-market abuse, SPE fraud, document shredding, lobbying) reflect real techniques used by Enron Corporation. This is not financial advice.
>
> **No Affiliation**: Not affiliated with Enron Corp (defunct), any named individuals, or any government agency.

---

## Credits

**Original Concept**: Enron: Meltdown Manager  
**Rebuilt by**: Glass Stone  
**CEO**: Gabriel B. Rodriguez  
**AI Engine**: Claude Sonnet 4.6 (Anthropic)  
**Year**: 2026  

---

## License

Educational use. Glass Stone © 2026. All rights reserved.

---

<p align="center">
  <em>"We are on the side of angels."</em> — Jeff Skilling, 2001
</p>
